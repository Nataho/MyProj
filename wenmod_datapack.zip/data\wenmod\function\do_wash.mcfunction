data modify entity @s Item.id set value "minecraft:dirt"
particle minecraft:block minecraft:dirt ~ ~0.2 ~ 0.2 0.2 0.2 0.1 12
playsound minecraft:entity.fishing_bobber.splash master @a ~ ~ ~ 0.8 0.6
