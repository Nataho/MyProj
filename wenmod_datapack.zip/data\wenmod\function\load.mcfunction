# Initialize scoreboards
scoreboard objectives add void_deaths custom:deaths "Void Deaths"
scoreboard objectives add ping dummy "ms"

# Set display slots if not already set
scoreboard objectives setdisplay sidebar void_deaths
scoreboard objectives setdisplay list ping

tellraw @a {"text":"[WenMod] Datapack initialized!","color":"green"}
