execute if block ~ ~ ~ minecraft:water_cauldron[level=1..3] run function wenmod:do_wash
