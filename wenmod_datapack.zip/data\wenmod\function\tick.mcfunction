# Washing coarse dirt in water cauldron -> convert to dirt + splash particle + sound
execute as @e[type=item,nbt={Item:{id:"minecraft:coarse_dirt"}}] at @s if block ~ ~ ~ #minecraft:cauldrons run function wenmod:wash_dirt
